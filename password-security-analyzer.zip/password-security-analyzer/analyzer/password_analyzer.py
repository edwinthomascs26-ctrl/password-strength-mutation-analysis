import re
import math


COMMON_PASSWORDS = {
    "password",
    "password@123",
    "Password@123",
    "123456",
    "12345678",
    "123456789",
    "qwerty",
    "qwerty123",
    "admin",
    "admin123",
    "letmein",
    "welcome",
    "abc123",
    "iloveyou",
}


def calculate_entropy(password):
    """
    Estimate password entropy using the size of the character pool.

    Entropy = password length × log2(character pool size)
    """

    pool_size = 0

    if re.search(r"[a-z]", password):
        pool_size += 26

    if re.search(r"[A-Z]", password):
        pool_size += 26

    if re.search(r"\d", password):
        pool_size += 10

    if re.search(r"[^A-Za-z0-9]", password):
        pool_size += 32

    if pool_size == 0:
        return 0, 0

    entropy = len(password) * math.log2(pool_size)

    return round(entropy, 2), pool_size


def estimate_crack_time(password):
    """
    Estimate brute-force crack time.

    This is an educational estimate, not a prediction of
    real-world cracking time.
    """

    entropy, pool_size = calculate_entropy(password)

    if entropy == 0:
        return {
            "seconds": 0,
            "formatted": "Instantly",
            "entropy": 0,
            "pool_size": 0
        }

    # Assumed guessing speed.
    # This is deliberately presented as an estimate.
    guesses_per_second = 1_000_000_000

    # Number of possible combinations.
    combinations = 2 ** entropy

    # Average brute-force time is approximately half
    # of the total search space.
    average_guesses = combinations / 2

    seconds = average_guesses / guesses_per_second

    # Format crack time
    if seconds < 1:
        formatted = "Less than a second"

    elif seconds < 60:
        formatted = f"{seconds:.2f} seconds"

    elif seconds < 3600:
        minutes = seconds / 60
        formatted = f"{minutes:.2f} minutes"

    elif seconds < 86400:
        hours = seconds / 3600
        formatted = f"{hours:.2f} hours"

    elif seconds < 31536000:
        days = seconds / 86400
        formatted = f"{days:.2f} days"

    elif seconds < 3153600000:
        years = seconds / 31536000
        formatted = f"{years:.2f} years"

    else:
        years = seconds / 31536000
        formatted = f"{years:.2e} years"

    return {
        "seconds": seconds,
        "formatted": formatted,
        "entropy": entropy,
        "pool_size": pool_size
    }


def analyze_password(password):
    score = 0
    checks = []

    # Length check
    if len(password) >= 8:
        score += 10
        checks.append({
            "name": "At least 8 characters",
            "passed": True
        })
    else:
        checks.append({
            "name": "At least 8 characters",
            "passed": False
        })

    # Stronger length
    if len(password) >= 12:
        score += 15

    # Uppercase check
    if re.search(r"[A-Z]", password):
        score += 15
        checks.append({
            "name": "Contains uppercase letter",
            "passed": True
        })
    else:
        checks.append({
            "name": "Contains uppercase letter",
            "passed": False
        })

    # Lowercase check
    if re.search(r"[a-z]", password):
        score += 15
        checks.append({
            "name": "Contains lowercase letter",
            "passed": True
        })
    else:
        checks.append({
            "name": "Contains lowercase letter",
            "passed": False
        })

    # Number check
    if re.search(r"\d", password):
        score += 15
        checks.append({
            "name": "Contains number",
            "passed": True
        })
    else:
        checks.append({
            "name": "Contains number",
            "passed": False
        })

    # Special character check
    if re.search(r"[^A-Za-z0-9]", password):
        score += 15
        checks.append({
            "name": "Contains special character",
            "passed": True
        })
    else:
        checks.append({
            "name": "Contains special character",
            "passed": False
        })

    # Common password check
    if password.lower() in COMMON_PASSWORDS:
        score -= 80
        checks.append({
            "name": "Not a common password",
            "passed": False
        })
    else:
        score += 10
        checks.append({
            "name": "Not a common password",
            "passed": True
        })

    # Sequential characters
    sequences = [
        "123456789",
        "987654321",
        "abcdefghijklmnopqrstuvwxyz",
        "zyxwvutsrqponmlkjihgfedcba"
    ]

    has_sequence = any(
        sequence in password.lower()
        for sequence in sequences
    )

    if has_sequence:
        score -= 15
        checks.append({
            "name": "Does not contain obvious sequences",
            "passed": False
        })
    else:
        score += 10
        checks.append({
            "name": "Does not contain obvious sequences",
            "passed": True
        })

    # Repeated characters
    if re.search(r"(.)\1\1", password):
        score -= 10
        checks.append({
            "name": "Avoids repeated characters",
            "passed": False
        })
    else:
        score += 5
        checks.append({
            "name": "Avoids repeated characters",
            "passed": True
        })

    # Keep score between 0 and 100
    score = max(0, min(score, 100))

    # Determine strength
    if score < 30:
        strength = "Very Weak"
    elif score < 50:
        strength = "Weak"
    elif score < 70:
        strength = "Medium"
    elif score < 85:
        strength = "Strong"
    else:
        strength = "Very Strong"

    # Recommendations
    
    recommendations = []

    if len(password) < 12:
        recommendations.append(
            "Use at least 12 characters to improve password strength."
        )

    if not re.search(r"[A-Z]", password):
        recommendations.append(
            "Add at least one uppercase letter (A-Z)."
        )

    if not re.search(r"[a-z]", password):
        recommendations.append(
            "Add at least one lowercase letter (a-z)."
        )

    if not re.search(r"\d", password):
        recommendations.append(
            "Include at least one number (0-9)."
        )

    if not re.search(r"[^A-Za-z0-9]", password):
        recommendations.append(
            "Include a special character, such as @, #, or !."
        )

    if password.lower() in COMMON_PASSWORDS:
        recommendations.append(
            "This is a commonly used password. Choose a unique one."
        )

    if has_sequence:
        recommendations.append(
            "Avoid predictable sequences such as 123456 or abcdef."
        )

    if re.search(r"(.)\1\1", password):
        recommendations.append(
            "Avoid repeating the same character three or more times."
        )

    if not recommendations:
        recommendations.append(
            "Good password structure! Avoid reusing it."
        )


    # -----------------------------------------
    # NEW: ENTROPY + CRACK TIME
    # -----------------------------------------

    crack_time = estimate_crack_time(password)

    return {
        "score": score,
        "strength": strength,

        "length": len(password),

        "entropy": crack_time["entropy"],
        "character_pool": crack_time["pool_size"],

        "crack_time": crack_time["formatted"],
        "crack_time_seconds": crack_time["seconds"],

        "checks": checks,
        "recommendations": recommendations
    }


if __name__ == "__main__":
    result = analyze_password("Password123!")

    print(result)