from flask import Flask, render_template, request, jsonify
from analyzer.password_analyzer import analyze_password
import sqlite3
from datetime import datetime

app = Flask(__name__)

DATABASE = "password_analysis.db"


# ---------------- DATABASE ----------------

def init_db():
    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            score INTEGER,
            strength TEXT,
            length INTEGER,
            entropy REAL,
            character_pool TEXT,
            crack_time TEXT
        )
    """)

    connection.commit()
    connection.close()


# ---------------- HOME ----------------

@app.route("/")
def home():
    return render_template("index.html")


# ---------------- ANALYZE ----------------

@app.route("/analyze", methods=["POST"])
def analyze():

    data = request.get_json()

    if not data or "password" not in data:
        return jsonify({
            "error": "Password is required"
        }), 400

    password = data["password"]

    if not isinstance(password, str):
        return jsonify({
            "error": "Invalid password format"
        }), 400

    result = analyze_password(password)

    # Save analysis result to database
    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO analyses
        (timestamp, score, strength, length, entropy,
         character_pool, crack_time)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        result["score"],
        result["strength"],
        result["length"],
        result["entropy"],
        result["character_pool"],
        result["crack_time"]
    ))

    connection.commit()
    connection.close()

    return jsonify(result)


# ---------------- DASHBOARD ----------------

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


# ---------------- DASHBOARD API ----------------

@app.route("/api/dashboard")
def dashboard_api():

    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()

    # Total analyses
    cursor.execute("""
        SELECT COUNT(*) AS total
        FROM analyses
    """)

    total = cursor.fetchone()["total"]

    # Strong passwords
    cursor.execute("""
        SELECT COUNT(*) AS count
        FROM analyses
        WHERE LOWER(strength) = 'strong'
    """)

    strong = cursor.fetchone()["count"]

    # Medium passwords
    cursor.execute("""
        SELECT COUNT(*) AS count
        FROM analyses
        WHERE LOWER(strength) = 'medium'
    """)

    medium = cursor.fetchone()["count"]

    # Weak passwords
    cursor.execute("""
        SELECT COUNT(*) AS count
        FROM analyses
        WHERE LOWER(strength) = 'weak'
    """)

    weak = cursor.fetchone()["count"]

    # Average score
    cursor.execute("""
        SELECT AVG(score) AS average
        FROM analyses
    """)

    average = cursor.fetchone()["average"]

    # Recent analyses
    cursor.execute("""
        SELECT timestamp, score, strength, length,
               entropy, character_pool, crack_time
        FROM analyses
        ORDER BY id DESC
        LIMIT 10
    """)

    recent = cursor.fetchall()

    connection.close()

    # Percentages
    if total > 0:
        strong_percentage = round((strong / total) * 100, 1)
        weak_percentage = round((weak / total) * 100, 1)
    else:
        strong_percentage = 0
        weak_percentage = 0

    return jsonify({
        "total": total,
        "strong": strong,
        "medium": medium,
        "weak": weak,
        "average_score": round(average, 1) if average else 0,
        "strong_percentage": strong_percentage,
        "weak_percentage": weak_percentage,
        "recent": [dict(row) for row in recent]
    })


# ---------------- START APPLICATION ----------------

if __name__ == "__main__":
    init_db()
    app.run(debug=True)