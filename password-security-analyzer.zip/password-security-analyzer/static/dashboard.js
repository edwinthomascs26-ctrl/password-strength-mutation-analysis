const totalAnalyses = document.getElementById("totalAnalyses");
const strongPasswords = document.getElementById("strongPasswords");
const mediumPasswords = document.getElementById("mediumPasswords");
const weakPasswords = document.getElementById("weakPasswords");

const averageScore = document.getElementById("averageScore");
const strongPercentage = document.getElementById("strongPercentage");
const weakPercentage = document.getElementById("weakPercentage");

const recentAnalyses = document.getElementById("recentAnalyses");


async function loadDashboard() {

    try {

        const response = await fetch("/api/dashboard");

        const data = await response.json();

        if (!response.ok) {
            throw new Error("Unable to load dashboard data");
        }


        // SUMMARY CARDS

        totalAnalyses.textContent = data.total;

        strongPasswords.textContent = data.strong;

        mediumPasswords.textContent = data.medium;

        weakPasswords.textContent = data.weak;


        // SECURITY OVERVIEW

        averageScore.textContent =
            data.average_score + "/100";

        strongPercentage.textContent =
            data.strong_percentage + "%";

        weakPercentage.textContent =
            data.weak_percentage + "%";


        // RECENT ANALYSES

        if (data.recent.length === 0) {

            recentAnalyses.innerHTML =
                "<p>No analyses yet.</p>";

            return;
        }


        recentAnalyses.innerHTML = "";


        data.recent.forEach(function (analysis) {

            const analysisItem =
                document.createElement("div");

            analysisItem.className =
                "analysis-item";


            analysisItem.innerHTML =
                "<p><strong>Strength:</strong> " +
                analysis.strength +
                "</p>" +

                "<p><strong>Score:</strong> " +
                analysis.score +
                "/100</p>" +

                "<p><strong>Length:</strong> " +
                analysis.length +
                "</p>" +

                "<p><strong>Entropy:</strong> " +
                analysis.entropy +
                " bits</p>" +

                "<p><strong>Character Pool:</strong> " +
                analysis.character_pool +
                "</p>" +

                "<p><strong>Crack Time:</strong> " +
                analysis.crack_time +
                "</p>" +

                "<p><strong>Date:</strong> " +
                analysis.timestamp +
                "</p>";


            recentAnalyses.appendChild(analysisItem);

        });


    } catch (error) {

        console.error(error);

        recentAnalyses.innerHTML =
            "<p>Unable to load dashboard data.</p>";

    }

}


// LOAD DASHBOARD

loadDashboard();