const passwordInput = document.getElementById("password");
const togglePassword = document.getElementById("togglePassword");
const analyzeButton = document.getElementById("analyzeButton");
const resultDiv = document.getElementById("result");

// SHOW / HIDE PASSWORD
togglePassword.onclick = function () {
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        togglePassword.textContent = "Hide";
    } else {
        passwordInput.type = "password";
        togglePassword.textContent = "Show";
    }
};

// ANALYZE PASSWORD
analyzeButton.onclick = async function () {
    const password = passwordInput.value;

    if (password.length === 0) {
        resultDiv.textContent = "Please enter a password.";
        return;
    }

    resultDiv.textContent = "Analyzing...";

    try {
        const response = await fetch("/analyze", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                password: password
            })
        });

        const data = await response.json();

        if (!response.ok) {
            resultDiv.textContent =
                data.error || "Password analysis failed.";
            return;
        }

        // PASSWORD RECOMMENDATIONS
        let recommendationsHTML = "";

        if (
            Array.isArray(data.recommendations) &&
            data.recommendations.length > 0
        ) {
            data.recommendations.forEach(function (recommendation) {
                recommendationsHTML += `<li>${recommendation}</li>`;
            });
        } else {
            recommendationsHTML =
                "<li>Your password structure looks good. Use a unique password.</li>";
        }

        // DISPLAY ANALYSIS RESULTS AND RECOMMENDATIONS
        resultDiv.innerHTML = `
        <h2>${data.strength}</h2>
        <p>Score: ${data.score}/100</p>
        <p>Length: ${data.length}</p>
        <p>Entropy: ${data.entropy} bits</p>
        <p>Character Pool: ${data.character_pool}</p>
        <p>Estimated Crack Time: ${data.crack_time}</p>

        <div class="recommendations">
            <h3>Recommendations to Improve Your Password</h3>
            <ul>${recommendationsHTML}</ul>
        </div>
        `;

    } catch (error) {
        console.error("Password analysis error:", error);

        resultDiv.textContent =
            "Unable to connect to the server. Please check whether Flask is running.";
    }
};